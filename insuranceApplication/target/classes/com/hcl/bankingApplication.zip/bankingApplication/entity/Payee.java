package com.hcl.bankingApplication.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Table(name = "payee")
@Data
public class Payee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payee_id")
	@JsonIgnore
	private Long payeeId;

	@Column(name = "payee_name")
	private String payeeName;

	@Column(name = "auth_code")
	private Integer authCode;

	@Column(name = "isConfirmed")
	private Boolean isConfirmed;
	

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="customer_id")
	private Customer customer;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="account_id")
	private Account account;
	
}
